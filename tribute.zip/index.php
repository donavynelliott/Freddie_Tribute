<?php


include_once('header.php');

include_once('homepage.php');

include_once('footer.php');