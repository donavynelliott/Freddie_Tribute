<div class="row">
	<div class="col-lg-1"></div>
	<div class="col-lg-11">
		<footer>Made by Donavyn Elliott 2017</footer>
	</div>
</div>
</body>
</html>